#include <QtGui>
#include <QtOpenGL>
#include <math.h>
#include "glDisplay3D.h"

GLWidget::GLWidget(QWidget *parent)
    : QGLWidget(parent)
{
    setFocusPolicy(Qt::StrongFocus);

    xRot = 0.0f;
    yRot = 0.0f;
    zRot = 0.0f;

    zTra = -20.0f;

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(advanceGL()));
    //timer->start(20);
}

void GLWidget::initializeGL()
{
    glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
    glClearDepth(1.0f);
    glShadeModel(GL_SMOOTH);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
}

void GLWidget::resizeGL(int width, int height)
{
    if (height==0)
        height=1;

    glViewport(0,0,width,height);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    GLfloat x = (GLfloat)width / (GLfloat)height;
    gluPerspective(45.0f, x, 0.1f, 100.0f);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void GLWidget::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    glTranslatef(0.0f, 0.0f, zTra);

    glRotatef(xRot, 1.0f, 0.0f, 0.0f);
    glRotatef(yRot, 0.0f, 1.0f, 0.0f);
    glRotatef(zRot, 0.0f, 0.0f, 1.0f);

    glColor3f(0.0f, 0.8f, 0.8f);

    draw();
}

void GLWidget::draw()
{
    glBegin(GL_LINE_LOOP);
            glVertex3f(-10.0f,  1.5f, -2.0f); //1
            glVertex3f(-10.0f,  1.5f,  0.0f); //2
            glVertex3f(-10.0f, -1.5f,  0.0f); //3
            glVertex3f(-10.0f, -1.5f, -2.0f); //4
    glEnd();

    glBegin(GL_LINE_LOOP);
            glVertex3f(-2.0f,  1.5f, -2.0f); //5
            glVertex3f(-2.0f,  1.5f,  0.0f); //6
            glVertex3f(-2.0f, -1.5f,  0.0f); //7
            glVertex3f(-2.0f, -1.5f, -2.0f); //8
    glEnd();

    glBegin(GL_LINE_LOOP);
            glVertex3f(-2.0f,  1.5f,  0.0f); //6
            glVertex3f(-10.0f, 1.5f,  0.0f); //2
            glVertex3f(-10.0f,-1.5f,  0.0f); //3
            glVertex3f(-2.0f, -1.5f,  0.0f); //7
    glEnd();

    glBegin(GL_LINE_LOOP);
            glVertex3f(-2.0f,  1.5f, -2.0f); //5
            glVertex3f(-10.0f, 1.5f, -2.0f); //1
            glVertex3f(-10.0f,-1.5f, -2.0f); //4
            glVertex3f(-2.0f, -1.5f, -2.0f); //8
    glEnd();

    glBegin(GL_LINE_LOOP);
            glVertex3f(-0.25f,  0.5f, -1.4f); //9
            glVertex3f(-0.25f,  0.5f, -0.7f); //10
            glVertex3f(-0.25f, -0.5f, -0.7f); //11
            glVertex3f(-0.25f, -0.5f, -1.4f); //12
    glEnd();

    glBegin(GL_LINE_LOOP);
            glVertex3f(-0.25f, 0.5f, -0.7f); //10
            glVertex3f(-2.0f,  1.5f,  0.0f); //6
            glVertex3f(-2.0f, -1.5f,  0.0f); //7
            glVertex3f(-0.25f,-0.5f, -0.7f); //11
    glEnd();

    glBegin(GL_LINE_LOOP);
            glVertex3f(-0.25f, 0.5f, -1.4f); //9
            glVertex3f(-2.0f,  1.5f, -2.0f); //5
            glVertex3f(-2.0f, -1.5f, -2.0f); //8
            glVertex3f(-0.25f,-0.5f, -1.4f); //12
    glEnd();

//////////////////////////////////////////////////////////////////////////////////////////////////////

    glBegin(GL_LINE_LOOP);
            glVertex3f(10.0f,  1.5f, -2.0f); //1
            glVertex3f(10.0f,  1.5f,  0.0f); //2
            glVertex3f(10.0f, -1.5f,  0.0f); //3
            glVertex3f(10.0f, -1.5f, -2.0f); //4
    glEnd();

    glBegin(GL_LINE_LOOP);
            glVertex3f(2.0f,  1.5f, -2.0f); //5
            glVertex3f(2.0f,  1.5f,  0.0f); //6
            glVertex3f(2.0f, -1.5f,  0.0f); //7
            glVertex3f(2.0f, -1.5f, -2.0f); //8
    glEnd();

    glBegin(GL_LINE_LOOP);
            glVertex3f(2.0f,  1.5f,  0.0f); //6
            glVertex3f(10.0f, 1.5f,  0.0f); //2
            glVertex3f(10.0f,-1.5f,  0.0f); //3
            glVertex3f(2.0f, -1.5f,  0.0f); //7
    glEnd();

    glBegin(GL_LINE_LOOP);
            glVertex3f(2.0f,  1.5f, -2.0f); //5
            glVertex3f(10.0f, 1.5f, -2.0f); //1
            glVertex3f(10.0f,-1.5f, -2.0f); //4
            glVertex3f(2.0f, -1.5f, -2.0f); //8
    glEnd();

    glBegin(GL_LINE_LOOP);
            glVertex3f(0.25f,  0.5f, -1.4f); //9
            glVertex3f(0.25f,  0.5f, -0.7f); //10
            glVertex3f(0.25f, -0.5f, -0.7f); //11
            glVertex3f(0.25f, -0.5f, -1.4f); //12
    glEnd();

    glBegin(GL_LINE_LOOP);
            glVertex3f(0.25f, 0.5f, -0.7f); //10
            glVertex3f(2.0f,  1.5f,  0.0f); //6
            glVertex3f(2.0f, -1.5f,  0.0f); //7
            glVertex3f(0.25f,-0.5f, -0.7f); //11
    glEnd();

    glBegin(GL_LINE_LOOP);
            glVertex3f(0.25f, 0.5f, -1.4f); //9
            glVertex3f(2.0f,  1.5f, -2.0f); //5
            glVertex3f(2.0f, -1.5f, -2.0f); //8
            glVertex3f(0.25f,-0.5f, -1.4f); //12
    glEnd();
}

void GLWidget::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_Space)
    {
        xRot = 0.0f;
        yRot = 0.0f;
        zRot = 0.0f;
    }
    else if (event->key() == Qt::Key_Left)
    {
        yRot -= 1.0f;
    }
    else if (event->key() == Qt::Key_Right)
    {
        yRot += 1.0f;
    }
    else if (event->key() == Qt::Key_Down)
    {
        xRot += 1.0f;
    }
    else if (event->key() == Qt::Key_Up)
    {
        xRot -= 1.0f;
    }
    else if (event->key() == Qt::Key_PageDown)
    {
        zTra -= 1.0f;
    }
    else if (event->key() == Qt::Key_PageUp)
    {
        zTra += 1.0f;
    }

    updateGL();
}

void GLWidget::mousePressEvent(QMouseEvent *event)
{
    lastPos = event->pos();
}

void GLWidget::mouseMoveEvent(QMouseEvent *event)
{
    int dx = event->x() - lastPos.x();
    int dy = event->y() - lastPos.y();

    if (event->buttons() & Qt::LeftButton)
    {
        xRot += (GLfloat)dy;
        yRot += (GLfloat)dx;
        updateGL();
    }
    else if (event->buttons() & Qt::RightButton)
    {
        xRot += (GLfloat)dy;
        zRot += (GLfloat)dx;
        updateGL();
    }

    lastPos = event->pos();
}

void GLWidget::wheelEvent(QWheelEvent *event)
{
    event->delta() > 0 ? zTra += 1.0f : zTra -= 1.0f;
    updateGL();
}

void GLWidget::advanceGL()
{
    updateGL();
}
