#include <QGLWidget>

class GLWidget : public QGLWidget
{
    Q_OBJECT

public:
    GLWidget(QWidget *parent = 0);

protected:
    void initializeGL();
    void resizeGL(int width, int height);
    void paintGL();

    void keyPressEvent(QKeyEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void wheelEvent(QWheelEvent *event);

private:
    void draw();

    GLfloat xRot;
    GLfloat yRot;
    GLfloat zRot;
    GLfloat zTra;

    QPoint lastPos;
    QTimer *timer;

private slots:
    void advanceGL();
};

