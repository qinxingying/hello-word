#ifndef DopplerCurveItem_H
#define DopplerCurveItem_H

#include "DopplerGraphicsItem.h"
#include <QColor>
//#include <QRectF>

#include <configure/DopplerConfigure.h>
#include <process/ParameterProcess.h>

class DopplerCurveItem : public DopplerGraphicsItem
{
public:
	enum CURVE_TYPE
	{
		CURVE_HOR ,
		CURVE_VER
	};
	DopplerCurveItem();
	void SetGroupId(int nGroupId_);

	void SetCurveType(CURVE_TYPE eType_);
	void SetLineStyle(Qt::PenStyle eStype_) ;
    void SetScenceSize(QSize);
    virtual void SetItemGeometry (QRectF& rect_);

protected:
    //void DrawLabel(QPainter* painter);
    QRectF boundingRect() const;
    QPainterPath shape() const;
    virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *item, QWidget *widget);
    void DrawLabel(QPainter *painter, QColor& cColor_, bool bSel_);
    //void mouseMoveEvent(QGraphicsSceneMouseEvent *event) ;
    //void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);

	void DrawLinearDacCurve(QPainter *painter);
	void DrawDacCurve(QPainter *painter);
	void DrawTcgCurve(QPainter *painter);

	void DrawPointRectangle(QPainter *painter_, float x_, float y_, QColor color_);

	DopplerConfigure* m_pConfig;
	ParameterProcess* m_process;
	GROUP_CONFIG*     m_pGroup;

	CURVE_TYPE		m_eCurveType;
	int				m_nGroupId;

	QRectF			m_rect   ;
	QColor			m_cColor[3] ;
	Qt::PenStyle	m_eStype ;
	QSize			m_cSize ;

};

#endif // DopplerCurveItem_H
