#include "DopplerCurveItem.h"
#include <QGraphicsScene>
#include <QPainter>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsSceneMouseEvent>
#include <math.h>

const int g_nRectSize = 0 ;
static int g_nCrZValue = 50 ;
DopplerCurveItem::DopplerCurveItem()
{
	m_nGroupId = -1;

	m_nWidth  = 100;
	m_nHeight = 100;

	double _nPos1  = 10 ;
	double _nPos2  = 10 ;
	m_rect.setLeft(_nPos1 - g_nRectSize) ;
	m_rect.setRight(_nPos1 + g_nRectSize);
	m_rect.setTop(_nPos2 - g_nRectSize);
	m_rect.setBottom(_nPos2 + g_nRectSize);

	m_cColor[2] = QColor(200 , 0  ,  0);
	m_cColor[1] = QColor(200 , 200,  0);
	m_cColor[0] = QColor(200 , 0  ,200);

	setZValue(g_nCrZValue);
//	SetMoveType(LINE_MOVE_NO) ;
	m_eStype = Qt::SolidLine  ;
//	setFlags(ItemIsSelectable);

	m_pConfig = DopplerConfigure::Instance() ;
	m_process = ParameterProcess::Instance();
	SetGroupId(0);
}

void DopplerCurveItem::SetGroupId(int nGroupId_)
{
	if(m_nGroupId != nGroupId_) {
		m_nGroupId = nGroupId_ ;
		//m_pTofd	   = m_pConfig->GetTofdConfig(m_nGroupId) ;
		m_pGroup   = &m_pConfig->group[m_nGroupId]  ;
		//m_pScanner = &m_pConfig->common.scanner;
		//m_iPosMax  = m_process->SAxisDistToIndex(m_pScanner->fScanStop);
	}
}

void DopplerCurveItem::SetCurveType(CURVE_TYPE eType_)
{
	m_eCurveType = eType_;
/*
	double _nPos1  = 10 ;
	double _nPos2  = 10 ;
	m_eLineType = eType_  ;
	if(m_eLineType == LINE_VERTICAL)  _nPos1 = 0 ;
	if(m_eLineType == LINE_HORIZENTAL)  _nPos2 = 0 ;


	m_rect.setLeft(_nPos1 - g_nRectSize) ;
	m_rect.setRight(_nPos1 + g_nRectSize);
	m_rect.setTop(_nPos2 - g_nRectSize);
	m_rect.setBottom(_nPos2 + g_nRectSize);
*/
}

void DopplerCurveItem::SetLineStyle(Qt::PenStyle eStype_)
{
	m_eStype = eStype_  ;
	update() ;
}

QRectF DopplerCurveItem::boundingRect() const
{
	QRectF _rect ;
	_rect = QRectF(-g_nRectSize , -g_nRectSize , m_nWidth+ g_nRectSize, m_nHeight+ g_nRectSize);
//	_rect = QRectF(0, 0 , m_cSize.width(), m_cSize.height() );
	return _rect;
}

QPainterPath DopplerCurveItem::shape() const
{
	QPainterPath path;
	QRectF _rct(0 , 0 , 0 , 0 ) ;
	if(!(flags() & QGraphicsItem::ItemIsPanel))
	_rct = boundingRect () ;
	path.addRect(_rct) ;
	return path;
}

void DopplerCurveItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget* /*widget*/)
{
	switch(m_pGroup->curve.nType)
	{
	case 1:	DrawDacCurve(painter);			break;
	case 2:	DrawLinearDacCurve(painter);	break;
	case 3:	DrawTcgCurve(painter);			break;
	}

}
#include "configure/DopplerConfigure.h"
void DopplerCurveItem::DrawLabel(QPainter *painter, QColor& cColor_, bool bSel_)
{
	QPen _pen = painter->pen();
	_pen.setColor(cColor_) ;
	painter->setPen(_pen);

	QString _str ;
/*	if(bSel_ && m_pDataView)
	{
		int _nGroup , _nLaw , _nDisp ;
		m_pDataView->GetDataViewConfigure(&_nGroup , &_nLaw , &_nDisp);

		DopplerConfigure* _pConfig = DopplerConfigure::Instance();

		float _fSStart;
		float _fSData = _pConfig->DefectLength(_nGroup, &_fSStart, m_nId);

		float _fUStart;
		float _fUData = _pConfig->DefectHeight(_nGroup, &_fUStart, m_nId);

		float _fDepth = _pConfig->DefectDepth(_nGroup, m_nId);
		if(_fDepth >= 0)
		{
			_fUStart = _fDepth;
		}
		_str.sprintf("%d: %.2f(%.2f) , %.2f(%.2f)", m_nId+1, _fSStart, _fSData, _fUStart, _fUData);
	}
	else*/
	{
		_str.sprintf("%d", m_nId+1)  ;
	}
	painter->drawText(0 , -4 , _str );
}

void DopplerCurveItem::DrawLinearDacCurve(QPainter *painter)
{
}

void DopplerCurveItem::DrawDacCurve(QPainter *painter)
{
}

void DopplerCurveItem::DrawTcgCurve(QPainter *painter)
{
	QColor _Color = m_cColor[0];

	painter->save();

	QPen _NewPen ;
	QVector<qreal> dashes;

	dashes << 2 << 6 << 2 << 6 ;

	_NewPen.setWidth(0);
	_NewPen.setColor(_Color);
	_NewPen.setStyle(m_eStype);
	_NewPen.setDashPattern(dashes);
	painter->setPen(_NewPen);

	//---------------------------------------------------------------
	CURVES& _curve = m_pGroup->curve;

	int _nWidth  = m_nWidth;
	int _nHeight = m_nHeight;

	int   _nBeamNo = 0;
	float _fTStart = m_pGroup->nTimeStart / 1000.0f;
	float _fTRange = m_pGroup->nTimeRange / 1000.0f;
	int _nPointQty = _curve.nPointQty;
	int _nPointPos = _curve.nPointPos;

	float _fRefAmpOff = pow(10, _curve.fAmpOffsetAmp / 2.0f);

	float _ptX[18] ;
	float _ptY[18] ;

	memset(_ptX, 0x00, sizeof(_ptX));
	memset(_ptY, 0x00, sizeof(_ptY));

	if(m_eCurveType == CURVE_HOR)
	{
		_ptX[0] = 0;
		_ptY[0] = _fRefAmpOff * _nHeight * _curve.faAmpRef[_nBeamNo];
		for(int i = 1; i < _nPointQty+1; i++ )
		{
			_ptX[i] = _nWidth * (_curve.faPosition[_nBeamNo][i-1] - _fTStart) / _fTRange;
			_ptY[i] = _fRefAmpOff * _nHeight * (_curve.faAmp[_nBeamNo][i-1] / 100.0f);
		}
		_ptX[_nPointQty+1] = _nWidth;
		_ptY[_nPointQty+1] = _ptY[_nPointQty];

		for(int i = _nPointQty+1; i >= 0 ; i--)
		{
			_ptY[i] = _nHeight - fabs(_ptY[i] - _ptY[0]);
		}
	}
	else
	{
		_ptX[0] = _fRefAmpOff * _nWidth * _curve.faAmpRef[_nBeamNo];;
		_ptY[0] = 0;
		for(int i = 1; i < _nPointQty+1; i++ )
		{
			_ptX[i] = _fRefAmpOff * _nWidth * (_curve.faAmp[_nBeamNo][i-1] / 100.0f);
			_ptY[i] = _nHeight * (_curve.faPosition[_nBeamNo][i-1] - _fTStart) / _fTRange;
		}
		_ptX[_nPointQty+1] = _ptX[_nPointQty];
		_ptY[_nPointQty+1] = _nHeight;

		for(int i = _nPointQty+1; i >= 0 ; i--)
		{
			_ptX[i] = fabs(_ptX[i] - _ptX[0]);
		}
	}

	for(int i = 1 ; i < _nPointQty+1 ; i ++)
	{
		painter->drawLine(_ptX[i] , _ptY[i] , _ptX[i+1] , _ptY[i+1]);
	}

	for (int i = 1; i <= _nPointQty; i++)
	{
		if ((i - 1) == _nPointPos) {
			DrawPointRectangle(painter, _ptX[i] , _ptY[i], QColor(200 , 0 , 0));
		} else {
			DrawPointRectangle(painter, _ptX[i] , _ptY[i], QColor(200 , 200 , 200));
		}
	}
	//---------------------------------------------------------------
	painter->restore();
}

void DopplerCurveItem::DrawPointRectangle(QPainter *painter_, float x_, float y_, QColor color_)
{
	const int HWIDTH = 3;
	QBrush _brush(color_);//(QColor(130,130,130) );
	QRectF _rect;

	_rect.setLeft(x_ - HWIDTH);
	_rect.setTop(y_ - HWIDTH);
	_rect.setRight(x_ + HWIDTH);
	_rect.setBottom(y_ + HWIDTH);

	painter_->fillRect(_rect, _brush);
}


/*
void draw_tcg_curve_horizontal(cairo_t *cr , int width , int height , int grp)
{
double point_x[18] ;
double point_y[18] ;


int i ;
int _nBeamNo = TMP(beam_num[grp]) ;
double sample_start = get_group_val (get_group_by_id (pp->p_config, grp), GROUP_START) / 1000.0 ;
double sample_range = get_group_val (get_group_by_id (pp->p_config, grp), GROUP_RANGE) / 1000.0;


int point_count = (int)GROUP_VAL_POS(grp , SizingCurves.dac_point_qty) ;
double ref_ampl_offset = pow( 10.0, GROUP_VAL_POS(grp , SizingCurves.ref_ampl_offset) / 2000.0 ) ;
int point_pos = GROUP_VAL_POS(grp , SizingCurves.point_pos)            ;
point_y[0] = ref_ampl_offset * height * GROUP_VAL_POS(grp , SizingCurves.dac_ref_ampl[_nBeamNo])/1000.0 ;
point_x[0] = 0 ;
cairo_set_source_rgb (cr, 0, 255 , 0);
cairo_set_line_width (cr, 0.5);
for( i = 1; i < point_count+1; i++ )
{
point_x [i] =  width * (GROUP_VAL_POS(grp , SizingCurves.position[_nBeamNo][i-1]) / 1000.0 - sample_start) / sample_range ;
point_y [i] =  ref_ampl_offset * height * (GROUP_VAL_POS(grp , SizingCurves.amplitude[_nBeamNo][i-1] ) / 100000.0) ;
}
point_x[point_count+1] = width ;
point_y[point_count+1] = point_y[point_count] ;


for(i = point_count+1; i>0 ; i-- )
{
point_y[i] = fabs(point_y[i] - point_y[0]) ;
}
point_y[0] = 0;


for(i = 0; i<= point_count; i++)
{
cairo_move_to(cr, 20 + point_x[i],   height - point_y[i] ) ;
cairo_line_to(cr, 20 + point_x[i+1], height - point_y[i+1]);
cairo_stroke(cr);
}


cairo_set_source_rgb (cr, 0.3, 0.3, 0.3 );
for(i = 1 ; i <= point_count ; i++)
{
if((i-1) == point_pos) continue ;
cairo_rectangle(cr , 17 + point_x[i], height - point_y[i] - 3, 6 ,6 );
cairo_fill(cr);
}
cairo_stroke(cr);
cairo_set_source_rgb (cr, 0.6, 0, 0 );
cairo_rectangle(cr , 17 + point_x[point_pos + 1], height - point_y[point_pos + 1] - 3, 6 ,6 );
cairo_fill(cr);
cairo_stroke(cr);
}*/

/*
void DopplerCurveItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
	DopplerGraphicsItem::mousePressEvent(event) ;
	mouseMoveEvent(event) ;
}
*/
void DopplerCurveItem::mouseReleaseEvent(QGraphicsSceneMouseEvent* event)
{
	//setSelected(false);
	//update();
}
/*
void DopplerCurveItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
}
*/
void DopplerCurveItem::SetItemGeometry (QRectF& rect_)
{
/*	QRectF _rect = rect_;
	int _w = _rect.width();
	int _h = _rect.height();
	int _x = _rect.left();
	int _y = _rect.top();

	if(_w < 0)
	{
		_x += _w;
		_w = abs(_w);
		_rect.setLeft(_x);
		_rect.setRight(_x+_w);
	}
	if(_h < 0)
	{
		_y += _h;
		_h = abs(_h);
		_rect.setTop(_y);
		_rect.setBottom(_y+_h);
	}


//	m_nWidth  = _rect.width();
//	m_nHeight = _rect.height();
	this->setPos(_rect.topLeft());*/
}

void DopplerCurveItem::SetScenceSize(QSize size_)
{
	m_cSize = size_ ;

	QRectF _rect;
	_rect.setLeft(0);
	_rect.setTop(0);
	_rect.setRight(m_cSize.width());
	_rect.setBottom(m_cSize.height());

	m_nWidth  = _rect.width();
	m_nHeight = _rect.height();
	this->setPos(_rect.topLeft());
}

